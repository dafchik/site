$(document).ready(function() {
    $('.menu-burger-header').click(function() {
        $('.menu-burger-header').toggleClass('open-menu');
        $('.mobile-menu').toggleClass('open-menu');
    });
});